
public class Binaryliterals {

	public static void main(String[] args) {
		  int a = 0b111;      
	        int b = 0B101;     
	        System.out.println("a = "+a);  
	        System.out.println("b = "+b);  
	          

	}

}
