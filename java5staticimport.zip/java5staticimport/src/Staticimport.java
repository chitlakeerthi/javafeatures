import static java.lang.System.*;    
public class Staticimport {

	public static void main(String[] args) {
		 out.println("Hello");
		   out.println("Java");  

	}

}
