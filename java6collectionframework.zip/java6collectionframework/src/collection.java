import java.util.*; 
public class collection{ 
    public static void main(String args[]){
        LinkedList<String> al=new LinkedList<String>();
        al.add("hi"); 
        al.add("hello"); 
        al.add("welcome"); 
        Iterator<String> itr = al.iterator();
        while(itr.hasNext()){ 
            System.out.println(itr.next());
        }
    }
}

