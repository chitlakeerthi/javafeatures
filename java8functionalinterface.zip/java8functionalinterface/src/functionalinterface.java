interface sayable{  
    void say(String msg);  
}  
public class functionalinterface implements sayable{  
    public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
    	functionalinterface a1 = new functionalinterface();  
        a1.say("Hello there");  
    }  
}  
