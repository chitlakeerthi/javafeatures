
public class multicatch {

	public static void main(String[] args) {
		 try{    
	          
				int array[] = new int[0];    
	            array[0] = 30/0;    
	        }    
	        catch(ArithmeticException | ArrayIndexOutOfBoundsException e){  
	            System.out.println(e.getMessage());  
	        }    
	     }    
	}  

	


