interface Sayable{  
    
    default void say(){  
        System.out.println("Hello, this is default method");  
    }  
 
    void sayMore(String msg);  
}  
public class defaultmethodes implements Sayable{  
    public void sayMore(String msg){        
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
    	defaultmethodes dm = new defaultmethodes();  
        dm.say();    
        dm.sayMore("Work is worship");  
  
    }  
}  

