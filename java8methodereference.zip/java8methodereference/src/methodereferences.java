interface Sayable{  
    void say();  
}  
public class methodereferences{  
    public static void saySomething(){  
        System.out.println("Hello");  
    }  
    public static void main(String[] args) {    
        Sayable sayable =methodereferences::saySomething;  
           sayable.say();  
    }  
}  
