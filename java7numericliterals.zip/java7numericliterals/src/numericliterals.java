
public class numericliterals {

	public static void main(String[] args) {
		 int a = 10_00000;  
	        System.out.println("a = "+a);  
	         
	        float b = 10.5_000f;  
	        System.out.println("b = "+b);  

	}

}
